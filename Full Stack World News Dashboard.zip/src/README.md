# 🌍 World News Dashboard

A professional full-stack news dashboard application that provides live world news updates from Wikipedia API with authentication, search, filtering, and theme support.

## ✨ Features

### 🔐 Authentication System
- **Sign Up**: Email validation, password strength requirements (8+ chars, 1 uppercase, 1 number)
- **Sign In**: Secure JWT-based authentication via Supabase
- **Password Reset**: Forgot password functionality with email recovery
- **Session Management**: Persistent user sessions

### 📰 News Dashboard
- **Live Wikipedia Integration**: Automatically fetches latest news from Wikipedia API
- **Auto-Refresh**: News updates when Wikipedia updates
- **Manual Refresh**: Refresh button to reload news on demand
- **Server-side Caching**: 5-minute cache to optimize API calls

### 🎨 UI/UX Features
- **Responsive Design**: Works seamlessly on desktop, tablet, and mobile
- **Day/Night Theme**: Toggle between light and dark modes (saved in localStorage)
- **Modern Animations**: Smooth transitions using Motion (Framer Motion)
- **Skeleton Loaders**: Shimmer effect while content loads
- **Professional Design**: Clean, modern news portal aesthetic

### 🔍 Search & Filter
- **Real-time Search**: Search any Wikipedia topic or news
- **Category Filters**: Filter by World, Politics, Technology, Sports, Science, Health, Business
- **Date Filters**: Filter by Today, Last 24h, This Week, All Time
- **Instant Results**: Fast search with Wikipedia API integration

### 📖 Article Reading
- **Internal Detail Page**: Custom-designed article view (not redirecting to Wikipedia)
- **Full Content**: Fetches complete article extracts from Wikipedia
- **Rich Formatting**: Properly formatted article content
- **Responsive Layout**: Optimized reading experience

### 💾 Bookmark System
- **Save Articles**: Bookmark articles for later reading
- **User-specific**: Each user has their own saved articles
- **Quick Access**: View all saved articles in dedicated modal
- **Persistent Storage**: Articles saved in Supabase database

## 🏗️ Architecture

### Frontend
- **React 18**: Modern React with hooks and context
- **TypeScript**: Type-safe development
- **Tailwind CSS**: Utility-first styling
- **Motion**: Smooth animations
- **Shadcn/UI**: Professional UI components

### Backend
- **Supabase Edge Functions**: Serverless backend with Hono framework
- **Wikipedia REST API**: Live news data source
- **Supabase Auth**: Secure authentication system
- **Key-Value Store**: Article bookmarking storage

### Entry Point
- **HTML Mount**: React app mounts from `/index.html` file
- **Vite-ready**: Fast development and production builds

## 📁 Project Structure

```
/
├── index.html                      # HTML entry point
├── src/
│   └── main.tsx                   # React mounting point
├── App.tsx                        # Main application component
├── contexts/
│   ├── AuthContext.tsx           # Authentication state management
│   └── ThemeContext.tsx          # Theme state management
├── components/
│   ├── auth/
│   │   ├── LoginForm.tsx         # Login UI
│   │   ├── SignUpForm.tsx        # Registration UI
│   │   └── ForgotPasswordForm.tsx # Password reset UI
│   ├── dashboard/
│   │   ├── Navbar.tsx            # Main navigation
│   │   ├── FilterBar.tsx         # Category & date filters
│   │   ├── NewsCard.tsx          # Article card component
│   │   ├── ArticleDetail.tsx     # Full article view
│   │   ├── SearchModal.tsx       # Search interface
│   │   ├── SavedArticles.tsx     # Bookmarked articles
│   │   └── NewsSkeleton.tsx      # Loading skeleton
│   └── ui/                       # Shadcn UI components
├── types/
│   └── index.ts                  # TypeScript type definitions
├── utils/
│   └── supabase/
│       ├── client.ts             # Supabase client setup
│       └── info.tsx              # Project credentials
└── supabase/
    └── functions/
        └── server/
            └── index.tsx          # Backend API server

```

## 🚀 API Endpoints

### News Endpoints
- `GET /news/latest` - Fetch latest news (cached 5 minutes)
- `GET /news/article/:title` - Get full article details
- `GET /news/search?q=query` - Search Wikipedia articles

### Auth Endpoints
- `POST /auth/register` - User registration with validation

### Article Management
- `POST /articles/save` - Save article (requires auth)
- `GET /articles/saved` - Get user's saved articles (requires auth)

## 🎯 Key Features Implementation

### Password Validation
- Minimum 8 characters
- At least 1 uppercase letter
- At least 1 number
- Visual password strength indicator

### Wikipedia Integration
- Fetches from multiple Wikipedia sources
- Combines Featured Feed, Current Events, and Topic searches
- Extracts structured data with thumbnails
- Automatic category assignment

### Caching Strategy
- Server-side caching prevents API rate limiting
- 5-minute cache duration
- Automatic cache invalidation on manual refresh

### Theme System
- System-wide dark/light mode
- Persistent across sessions (localStorage)
- Smooth transitions between themes
- Optimized color palettes for both modes

## 📱 Responsive Breakpoints

- **Mobile**: < 768px (Single column, mobile menu)
- **Tablet**: 768px - 1024px (2-column grid)
- **Desktop**: > 1024px (3-column grid, full features)

## 🔒 Security Features

- JWT-based authentication
- Password hashing (handled by Supabase)
- Secure HTTP-only sessions
- Protected API routes
- Input validation and sanitization

## 🎨 Design System

- **Colors**: Adaptive color scheme for light/dark modes
- **Typography**: Consistent font sizing and weights
- **Spacing**: 4px base unit system
- **Animations**: 200-300ms transition times
- **Shadows**: Layered elevation system

## 📝 Notes

- News updates automatically when Wikipedia updates
- Supabase handles all backend infrastructure
- Production-ready with error handling and loading states
- Optimized for performance with caching and lazy loading
- Fully accessible with keyboard navigation support

---

Built with ❤️ using React, Supabase, and Wikipedia API
