export interface NewsArticle {
  id: string;
  title: string;
  summary: string;
  thumbnail?: string;
  category: string;
  timestamp: string;
  link: string;
  fullExtract?: string;
}

export interface User {
  id: string;
  email: string;
  name: string;
}

export interface AuthContextType {
  user: User | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string, name: string) => Promise<void>;
  signOut: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
}

export type Theme = 'light' | 'dark';

export type NewsCategory = 'All' | 'World' | 'Politics' | 'Technology' | 'Sports' | 'Science' | 'Health' | 'Business';

export interface NewsFilters {
  category: NewsCategory;
  searchQuery: string;
  dateFilter: 'today' | '24h' | 'week' | 'all';
}
