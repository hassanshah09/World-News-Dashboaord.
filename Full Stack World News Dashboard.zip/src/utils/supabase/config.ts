// Deployment-ready configuration
// This file supports both Figma Make auto-generated values and custom environment variables

// Safely check for environment variables
const getSupabaseUrl = () => {
  // Check if import.meta.env exists and has the variable
  if (typeof import.meta !== 'undefined' && 
      import.meta.env && 
      import.meta.env.VITE_SUPABASE_URL) {
    return import.meta.env.VITE_SUPABASE_URL;
  }
  // Fallback to auto-generated (works in Figma Make environment)
  return 'https://olyqsjpbgesmyyozudeb.supabase.co';
};

const getSupabaseAnonKey = () => {
  // Check if import.meta.env exists and has the variable
  if (typeof import.meta !== 'undefined' && 
      import.meta.env && 
      import.meta.env.VITE_SUPABASE_ANON_KEY) {
    return import.meta.env.VITE_SUPABASE_ANON_KEY;
  }
  // Fallback to auto-generated (works in Figma Make environment)
  return 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9seXFzanBiZ2VzbXl5b3p1ZGViIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjMxMDA0NTUsImV4cCI6MjA3ODY3NjQ1NX0.6FPxSYltiTiVPldY5bz4ZlN6ZfIHax1XZSZptDqzgSY';
};

export const supabaseUrl = getSupabaseUrl();
export const supabaseAnonKey = getSupabaseAnonKey();
export const projectId = supabaseUrl.split('.')[0].replace('https://', '');
export const publicAnonKey = supabaseAnonKey;
