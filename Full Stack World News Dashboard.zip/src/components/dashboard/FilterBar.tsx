import React from 'react';
import { motion } from 'motion/react';
import { Filter, Calendar, RefreshCw } from 'lucide-react';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../ui/select';
import type { NewsCategory, NewsFilters } from '../../types';

interface FilterBarProps {
  filters: NewsFilters;
  onFiltersChange: (filters: NewsFilters) => void;
  onRefresh: () => void;
  isRefreshing: boolean;
}

const categories: NewsCategory[] = [
  'All',
  'World',
  'Politics',
  'Technology',
  'Sports',
  'Science',
  'Health',
  'Business'
];

export function FilterBar({ filters, onFiltersChange, onRefresh, isRefreshing }: FilterBarProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-card border border-border rounded-xl p-4 shadow-sm"
    >
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
        <div className="flex items-center gap-2 flex-wrap">
          <Filter className="h-5 w-5 text-muted-foreground" />
          <span className="text-sm">Filter by:</span>
          
          {/* Category Filter */}
          <div className="flex gap-2 flex-wrap">
            {categories.map((category) => (
              <Badge
                key={category}
                variant={filters.category === category ? 'default' : 'outline'}
                className="cursor-pointer hover:bg-primary/80 transition-colors"
                onClick={() => onFiltersChange({ ...filters, category })}
              >
                {category}
              </Badge>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Date Filter */}
          <Select
            value={filters.dateFilter}
            onValueChange={(value: any) => onFiltersChange({ ...filters, dateFilter: value })}
          >
            <SelectTrigger className="w-[140px]">
              <Calendar className="h-4 w-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Time</SelectItem>
              <SelectItem value="today">Today</SelectItem>
              <SelectItem value="24h">Last 24h</SelectItem>
              <SelectItem value="week">This Week</SelectItem>
            </SelectContent>
          </Select>

          {/* Refresh Button */}
          <Button
            variant="outline"
            size="icon"
            onClick={onRefresh}
            disabled={isRefreshing}
          >
            <RefreshCw className={`h-4 w-4 ${isRefreshing ? 'animate-spin' : ''}`} />
          </Button>
        </div>
      </div>
    </motion.div>
  );
}
