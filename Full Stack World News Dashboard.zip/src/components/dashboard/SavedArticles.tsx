import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Bookmark, Loader2 } from 'lucide-react';
import { Button } from '../ui/button';
import { NewsCard } from './NewsCard';
import type { NewsArticle } from '../../types';
import { projectId, publicAnonKey } from '../../utils/supabase/info';
import { createClient } from '../../utils/supabase/client';

interface SavedArticlesProps {
  isOpen: boolean;
  onClose: () => void;
  onArticleSelect: (article: NewsArticle) => void;
}

export function SavedArticles({ isOpen, onClose, onArticleSelect }: SavedArticlesProps) {
  const [articles, setArticles] = useState<NewsArticle[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isOpen) {
      fetchSavedArticles();
    }
  }, [isOpen]);

  const fetchSavedArticles = async () => {
    setLoading(true);
    try {
      const supabase = createClient();
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session?.access_token) {
        console.error('No access token available');
        setArticles([]);
        return;
      }

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-e3bffcda/articles/saved`,
        {
          headers: {
            'Authorization': `Bearer ${session.access_token}`
          }
        }
      );

      if (!response.ok) {
        throw new Error('Failed to fetch saved articles');
      }

      const data = await response.json();
      setArticles(data.articles || []);
    } catch (error) {
      console.error('Error fetching saved articles:', error);
      setArticles([]);
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 overflow-y-auto"
        onClick={onClose}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="min-h-screen px-4 py-8"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="max-w-6xl mx-auto">
            {/* Header */}
            <div className="bg-card border border-border rounded-xl p-6 shadow-lg mb-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Bookmark className="h-6 w-6 text-primary" />
                  <div>
                    <h2>Saved Articles</h2>
                    <p className="text-sm text-muted-foreground">
                      {articles.length} article{articles.length !== 1 ? 's' : ''} saved
                    </p>
                  </div>
                </div>
                <Button variant="ghost" size="icon" onClick={onClose}>
                  <X className="h-5 w-5" />
                </Button>
              </div>
            </div>

            {/* Content */}
            {loading && (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            )}

            {!loading && articles.length === 0 && (
              <div className="text-center py-12 bg-card border border-border rounded-xl">
                <Bookmark className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3>No saved articles</h3>
                <p className="text-muted-foreground">
                  Start bookmarking articles to read them later
                </p>
              </div>
            )}

            {!loading && articles.length > 0 && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {articles.map((article, index) => (
                  <NewsCard
                    key={article.id}
                    article={article}
                    index={index}
                    onReadMore={(article) => {
                      onArticleSelect(article);
                      onClose();
                    }}
                  />
                ))}
              </div>
            )}
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
