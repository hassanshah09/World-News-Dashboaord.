import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, ExternalLink, Clock, Bookmark, Loader2 } from 'lucide-react';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import type { NewsArticle } from '../../types';
import { projectId, publicAnonKey } from '../../utils/supabase/config';
import { ImageWithFallback } from '../figma/ImageWithFallback';

interface ArticleDetailProps {
  article: NewsArticle;
  onBack: () => void;
  onSave?: (article: NewsArticle) => void;
}

export function ArticleDetail({ article, onBack, onSave }: ArticleDetailProps) {
  const [fullArticle, setFullArticle] = useState<NewsArticle>(article);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const fetchFullArticle = async () => {
      if (article.fullExtract) {
        setFullArticle(article);
        return;
      }

      setLoading(true);
      try {
        const response = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-e3bffcda/news/article/${encodeURIComponent(article.title)}`,
          {
            headers: {
              'Authorization': `Bearer ${publicAnonKey}`
            }
          }
        );

        if (!response.ok) {
          throw new Error('Failed to fetch article');
        }

        const data = await response.json();
        setFullArticle({
          ...article,
          fullExtract: data.fullExtract || data.summary,
          summary: data.summary || article.summary
        });
      } catch (error) {
        console.error('Error fetching full article:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchFullArticle();
  }, [article]);

  const formatTimeAgo = (timestamp: string) => {
    const now = new Date();
    const then = new Date(timestamp);
    const diffInMinutes = Math.floor((now.getTime() - then.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 60) return `${diffInMinutes} minutes ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)} hours ago`;
    return `${Math.floor(diffInMinutes / 1440)} days ago`;
  };

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      World: 'bg-blue-500/10 text-blue-600 dark:text-blue-400',
      Politics: 'bg-purple-500/10 text-purple-600 dark:text-purple-400',
      Technology: 'bg-green-500/10 text-green-600 dark:text-green-400',
      Sports: 'bg-orange-500/10 text-orange-600 dark:text-orange-400',
      Science: 'bg-cyan-500/10 text-cyan-600 dark:text-cyan-400',
      Health: 'bg-pink-500/10 text-pink-600 dark:text-pink-400',
      Business: 'bg-yellow-500/10 text-yellow-600 dark:text-yellow-400',
    };
    return colors[category] || 'bg-gray-500/10 text-gray-600 dark:text-gray-400';
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen bg-background"
    >
      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Back Button */}
        <Button
          variant="ghost"
          onClick={onBack}
          className="mb-6"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to News
        </Button>

        {/* Article Content */}
        <article className="bg-card border border-border rounded-xl overflow-hidden shadow-lg">
          {/* Featured Image */}
          {fullArticle.thumbnail && (
            <div className="relative h-96 overflow-hidden bg-muted">
              <ImageWithFallback
                src={fullArticle.thumbnail}
                alt={fullArticle.title}
                className="w-full h-full object-cover"
              />
            </div>
          )}

          <div className="p-8">
            {/* Meta Info */}
            <div className="flex items-center justify-between gap-4 mb-6 flex-wrap">
              <div className="flex items-center gap-3">
                <Badge className={getCategoryColor(fullArticle.category)}>
                  {fullArticle.category}
                </Badge>
                <span className="text-sm text-muted-foreground flex items-center gap-1">
                  <Clock className="h-4 w-4" />
                  {formatTimeAgo(fullArticle.timestamp)}
                </span>
              </div>

              <div className="flex items-center gap-2">
                {onSave && (
                  <Button
                    variant="outline"
                    onClick={() => onSave(fullArticle)}
                  >
                    <Bookmark className="mr-2 h-4 w-4" />
                    Save
                  </Button>
                )}
                <Button
                  variant="outline"
                  onClick={() => window.open(fullArticle.link, '_blank')}
                >
                  <ExternalLink className="mr-2 h-4 w-4" />
                  View on Wikipedia
                </Button>
              </div>
            </div>

            {/* Title */}
            <h1 className="mb-6">{fullArticle.title}</h1>

            {/* Content */}
            {loading ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : (
              <div className="prose prose-lg dark:prose-invert max-w-none">
                <div 
                  className="text-foreground leading-relaxed space-y-4"
                  dangerouslySetInnerHTML={{ 
                    __html: fullArticle.fullExtract || fullArticle.summary 
                  }}
                />
              </div>
            )}

            {/* Footer */}
            <div className="mt-8 pt-6 border-t border-border">
              <p className="text-sm text-muted-foreground">
                This content is sourced from Wikipedia and is updated automatically when Wikipedia updates.
              </p>
            </div>
          </div>
        </article>
      </div>
    </motion.div>
  );
}