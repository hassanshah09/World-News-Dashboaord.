import React from 'react';
import { motion } from 'motion/react';
import { Clock, ExternalLink, Bookmark } from 'lucide-react';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import type { NewsArticle } from '../../types';
import { ImageWithFallback } from '../figma/ImageWithFallback';

interface NewsCardProps {
  article: NewsArticle;
  index: number;
  onReadMore: (article: NewsArticle) => void;
  onSave?: (article: NewsArticle) => void;
}

export function NewsCard({ article, index, onReadMore, onSave }: NewsCardProps) {
  const formatTimeAgo = (timestamp: string) => {
    const now = new Date();
    const then = new Date(timestamp);
    const diffInMinutes = Math.floor((now.getTime() - then.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`;
    return `${Math.floor(diffInMinutes / 1440)}d ago`;
  };

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      World: 'bg-blue-500/10 text-blue-600 dark:text-blue-400',
      Politics: 'bg-purple-500/10 text-purple-600 dark:text-purple-400',
      Technology: 'bg-green-500/10 text-green-600 dark:text-green-400',
      Sports: 'bg-orange-500/10 text-orange-600 dark:text-orange-400',
      Science: 'bg-cyan-500/10 text-cyan-600 dark:text-cyan-400',
      Health: 'bg-pink-500/10 text-pink-600 dark:text-pink-400',
      Business: 'bg-yellow-500/10 text-yellow-600 dark:text-yellow-400',
    };
    return colors[category] || 'bg-gray-500/10 text-gray-600 dark:text-gray-400';
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05, duration: 0.3 }}
      whileHover={{ y: -4 }}
      className="bg-card border border-border rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all group"
    >
      {/* Thumbnail */}
      {article.thumbnail && (
        <div className="relative h-48 overflow-hidden bg-muted">
          <ImageWithFallback
            src={article.thumbnail}
            alt={article.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
          {onSave && (
            <Button
              size="icon"
              variant="secondary"
              className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
              onClick={(e) => {
                e.stopPropagation();
                onSave(article);
              }}
            >
              <Bookmark className="h-4 w-4" />
            </Button>
          )}
        </div>
      )}

      <div className="p-5 space-y-3">
        {/* Category & Time */}
        <div className="flex items-center justify-between gap-2">
          <Badge className={getCategoryColor(article.category)}>
            {article.category}
          </Badge>
          <span className="text-xs text-muted-foreground flex items-center gap-1">
            <Clock className="h-3 w-3" />
            {formatTimeAgo(article.timestamp)}
          </span>
        </div>

        {/* Title */}
        <h3 className="line-clamp-2 group-hover:text-primary transition-colors">
          {article.title}
        </h3>

        {/* Summary */}
        <p className="text-sm text-muted-foreground line-clamp-3">
          {article.summary}
        </p>

        {/* Actions */}
        <div className="flex items-center gap-2 pt-2">
          <Button
            onClick={() => onReadMore(article)}
            className="flex-1"
          >
            Read More
          </Button>
          <Button
            variant="outline"
            size="icon"
            onClick={() => window.open(article.link, '_blank')}
          >
            <ExternalLink className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </motion.div>
  );
}
