# 🚀 Deployment Guide

## Prerequisites

Before deploying, make sure you have:
1. A GitHub account with your code pushed to a repository
2. Your Supabase project set up and running
3. The Supabase backend (Edge Functions) already deployed

## Option 1: Deploy to Vercel ▲

### Step-by-Step Instructions:

1. **Go to Vercel**
   - Visit [vercel.com](https://vercel.com)
   - Sign in with GitHub

2. **Import Your Project**
   - Click "Add New Project"
   - Select your GitHub repository
   - Click "Import"

3. **Configure Build Settings**
   - Framework Preset: **Vite**
   - Build Command: `npm run build`
   - Output Directory: `dist`
   - Install Command: `npm install`

4. **Add Environment Variables** (IMPORTANT!)
   
   You need to add these environment variables in Vercel:
   
   Go to Project Settings → Environment Variables and add:
   
   ```
   VITE_SUPABASE_URL=your_supabase_project_url
   VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
   ```
   
   ⚠️ **Note**: Since Figma Make auto-generates these, you'll need to export them first.

5. **Deploy**
   - Click "Deploy"
   - Wait for the build to complete (2-3 minutes)
   - Your app will be live at `your-project.vercel.app`

### Vercel CLI (Alternative Method)

```bash
# Install Vercel CLI
npm i -g vercel

# Login
vercel login

# Deploy
vercel

# Deploy to production
vercel --prod
```

---

## Option 2: Deploy to Netlify 🎯

### Step-by-Step Instructions:

1. **Go to Netlify**
   - Visit [netlify.com](https://netlify.com)
   - Sign in with GitHub

2. **Import Your Project**
   - Click "Add new site" → "Import an existing project"
   - Choose "Deploy with GitHub"
   - Select your repository

3. **Configure Build Settings**
   - Build command: `npm run build`
   - Publish directory: `dist`
   - Node version: `18`

4. **Add Environment Variables** (IMPORTANT!)
   
   Go to Site Settings → Build & Deploy → Environment and add:
   
   ```
   VITE_SUPABASE_URL=your_supabase_project_url
   VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
   ```

5. **Deploy**
   - Click "Deploy site"
   - Wait for the build (2-3 minutes)
   - Your app will be live at `your-project.netlify.app`

### Netlify CLI (Alternative Method)

```bash
# Install Netlify CLI
npm i -g netlify-cli

# Login
netlify login

# Initialize
netlify init

# Deploy
netlify deploy

# Deploy to production
netlify deploy --prod
```

---

## 🔧 Fixing Common Deployment Errors

### Error: "Module not found" or "Cannot find module"

**Solution**: Make sure all dependencies are in `package.json`

```bash
# Locally test the build
npm install
npm run build
npm run preview
```

### Error: "Environment variables not defined"

**Solution**: You need to manually add Supabase credentials

Since this app is built in Figma Make, the Supabase credentials are auto-injected. For deployment:

1. Check your Supabase project dashboard
2. Go to Project Settings → API
3. Copy the Project URL and anon/public key
4. Add them as environment variables in Vercel/Netlify

**Update the code to use environment variables:**

In `/utils/supabase/info.tsx`, change:

```typescript
// Instead of auto-generated values, use:
export const projectId = import.meta.env.VITE_SUPABASE_URL?.split('.')[0].replace('https://', '') || 'your-project-id';
export const publicAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'your-anon-key';
```

### Error: "Build failed" or "Command failed"

**Solution**: Check the build logs

Common fixes:
```bash
# Clear cache and reinstall
rm -rf node_modules package-lock.json
npm install

# Try building locally
npm run build
```

### Error: "404 on page refresh"

**Solution**: Already handled! The `vercel.json` and `netlify.toml` files include redirects.

If you still see this error, ensure:
- `vercel.json` or `netlify.toml` is in your root directory
- The redirect rules are properly configured

---

## 📋 Pre-Deployment Checklist

Before deploying, verify:

- ✅ All files are committed to GitHub
- ✅ `package.json` has all dependencies
- ✅ `vite.config.ts` is present
- ✅ `vercel.json` or `netlify.toml` is configured
- ✅ Build works locally (`npm run build`)
- ✅ Supabase Edge Functions are deployed
- ✅ You have your Supabase credentials ready

---

## 🔐 Environment Variables Setup

### For Figma Make Users:

If you're deploying from Figma Make, you'll need to:

1. **Get your Supabase credentials:**
   - Open Supabase Dashboard
   - Go to Settings → API
   - Copy "Project URL" and "anon public" key

2. **Update `/utils/supabase/info.tsx`:**

Replace the auto-generated file with environment variable support:

```typescript
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://your-project.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'your-anon-key';

export const projectId = supabaseUrl.split('.')[0].replace('https://', '');
export const publicAnonKey = supabaseAnonKey;
```

3. **Add to Vercel/Netlify:**
   - `VITE_SUPABASE_URL=https://yourproject.supabase.co`
   - `VITE_SUPABASE_ANON_KEY=your-anon-key-here`

---

## 🎉 Post-Deployment

After successful deployment:

1. **Test Authentication**
   - Try signing up and logging in
   - Check if sessions persist

2. **Test News Fetching**
   - Verify news loads correctly
   - Try the refresh button
   - Test search functionality

3. **Test Bookmarking**
   - Save some articles
   - Check if they persist after logout/login

4. **Check Mobile Responsiveness**
   - Test on different screen sizes
   - Verify theme switching works

---

## 🆘 Still Having Issues?

### Check Build Logs
- Vercel: Go to Deployments → Click on failed deployment → View logs
- Netlify: Go to Deploys → Click on failed deploy → Deploy log

### Common Issues:

1. **Import errors**: Check file paths (case-sensitive on production)
2. **Missing dependencies**: Check `package.json`
3. **Environment variables**: Ensure they're set in platform settings
4. **API errors**: Verify Supabase Edge Functions are deployed
5. **CORS errors**: Check Supabase settings allow your domain

---

## 📞 Need Help?

If you encounter specific errors:
1. Copy the full error message
2. Check the build logs
3. Verify all configuration files are present
4. Test the build locally first

---

## 🔄 Continuous Deployment

Both Vercel and Netlify support automatic deployments:

- **Every push to main branch** = Automatic deployment
- **Pull requests** = Preview deployments
- **Rollback** = One-click rollback to previous version

Your app will automatically redeploy when you push changes to GitHub! 🎉
