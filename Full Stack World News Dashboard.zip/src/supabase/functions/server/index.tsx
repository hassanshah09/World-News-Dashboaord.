import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { logger } from 'npm:hono/logger';
import { createClient } from 'jsr:@supabase/supabase-js@2';
import * as kv from './kv_store.tsx';

const app = new Hono();

// Middleware
app.use('*', cors());
app.use('*', logger(console.log));

// Initialize Supabase client
const supabase = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
);

// Helper function to fetch from Wikipedia API
async function fetchWikipediaNews() {
  try {
    // Fetch "In the news" section from Wikipedia main page
    const response = await fetch(
      'https://en.wikipedia.org/api/rest_v1/page/html/Wikipedia:In_the_news'
    );
    
    if (!response.ok) {
      throw new Error(`Wikipedia API error: ${response.status}`);
    }

    // For simplicity, we'll use the Featured Feed API which provides structured news
    const feedResponse = await fetch(
      'https://en.wikipedia.org/api/rest_v1/feed/featured/' + 
      new Date().toISOString().split('T')[0].replace(/-/g, '/')
    );

    if (!feedResponse.ok) {
      throw new Error(`Wikipedia Feed API error: ${feedResponse.status}`);
    }

    const feedData = await feedResponse.json();
    
    // Also fetch "In the news" from the main page
    const newsResponse = await fetch(
      'https://en.wikipedia.org/api/rest_v1/page/summary/Wikipedia:In_the_news'
    );

    let newsArticles: any[] = [];

    // Fetch current events
    const currentEventsResponse = await fetch(
      'https://en.wikipedia.org/api/rest_v1/page/summary/Portal:Current_events'
    );

    // Get multiple news articles from different sources
    const searchTopics = ['World_news', 'Politics', 'Technology', 'Sports', 'Science', 'Health', 'Business'];
    
    const articlesPromises = searchTopics.map(async (topic) => {
      try {
        const res = await fetch(
          `https://en.wikipedia.org/w/api.php?action=query&format=json&origin=*&list=search&srsearch=${topic}&srlimit=5&srprop=snippet`
        );
        const data = await res.json();
        return data.query?.search || [];
      } catch (err) {
        console.error(`Error fetching ${topic}:`, err);
        return [];
      }
    });

    const articlesArrays = await Promise.all(articlesPromises);
    const allArticles = articlesArrays.flat();

    // Get detailed info for each article
    const detailedArticles = await Promise.all(
      allArticles.slice(0, 30).map(async (article: any, index: number) => {
        try {
          const summaryRes = await fetch(
            `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(article.title)}`
          );
          const summary = await summaryRes.json();
          
          return {
            id: `article-${index}-${Date.now()}`,
            title: summary.title || article.title,
            summary: summary.extract || article.snippet?.replace(/<[^>]*>/g, '') || 'No summary available',
            thumbnail: summary.thumbnail?.source || summary.originalimage?.source,
            category: searchTopics[Math.floor(index / 5)] || 'World',
            timestamp: new Date().toISOString(),
            link: summary.content_urls?.desktop?.page || `https://en.wikipedia.org/wiki/${encodeURIComponent(article.title)}`
          };
        } catch (err) {
          console.error(`Error fetching summary for ${article.title}:`, err);
          return null;
        }
      })
    );

    newsArticles = detailedArticles.filter(article => article !== null);

    return newsArticles;
  } catch (error) {
    console.error('Error fetching Wikipedia news:', error);
    throw error;
  }
}

// Route: Get latest news (with caching)
app.get('/make-server-e3bffcda/news/latest', async (c) => {
  try {
    // Check cache first
    const cached = await kv.get('wikipedia_news_cache');
    const cacheTimestamp = await kv.get('wikipedia_news_cache_timestamp');

    const now = Date.now();
    const fiveMinutes = 5 * 60 * 1000;

    // Return cached data if it's less than 5 minutes old
    if (cached && cacheTimestamp && (now - parseInt(cacheTimestamp)) < fiveMinutes) {
      console.log('Returning cached news data');
      return c.json({ articles: JSON.parse(cached), cached: true });
    }

    // Fetch fresh data
    console.log('Fetching fresh news data from Wikipedia');
    const articles = await fetchWikipediaNews();

    // Cache the results
    await kv.set('wikipedia_news_cache', JSON.stringify(articles));
    await kv.set('wikipedia_news_cache_timestamp', now.toString());

    return c.json({ articles, cached: false });
  } catch (error) {
    console.error('Error in /news/latest route:', error);
    return c.json({ error: 'Failed to fetch news', message: String(error) }, 500);
  }
});

// Route: Get article details
app.get('/make-server-e3bffcda/news/article/:title', async (c) => {
  try {
    const title = c.req.param('title');
    
    // Fetch full article extract from Wikipedia
    const response = await fetch(
      `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(title)}`
    );

    if (!response.ok) {
      throw new Error(`Wikipedia API error: ${response.status}`);
    }

    const data = await response.json();

    return c.json({
      title: data.title,
      summary: data.extract,
      fullExtract: data.extract_html || data.extract,
      thumbnail: data.thumbnail?.source || data.originalimage?.source,
      link: data.content_urls?.desktop?.page
    });
  } catch (error) {
    console.error('Error fetching article details:', error);
    return c.json({ error: 'Failed to fetch article details', message: String(error) }, 500);
  }
});

// Route: Search Wikipedia
app.get('/make-server-e3bffcda/news/search', async (c) => {
  try {
    const query = c.req.query('q');
    
    if (!query) {
      return c.json({ error: 'Search query is required' }, 400);
    }

    const response = await fetch(
      `https://en.wikipedia.org/w/api.php?action=query&format=json&origin=*&list=search&srsearch=${encodeURIComponent(query)}&srlimit=20&srprop=snippet`
    );

    const data = await response.json();
    const searchResults = data.query?.search || [];

    // Get detailed summaries for search results
    const articles = await Promise.all(
      searchResults.map(async (result: any, index: number) => {
        try {
          const summaryRes = await fetch(
            `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(result.title)}`
          );
          const summary = await summaryRes.json();
          
          return {
            id: `search-${index}-${Date.now()}`,
            title: summary.title,
            summary: summary.extract || result.snippet?.replace(/<[^>]*>/g, ''),
            thumbnail: summary.thumbnail?.source || summary.originalimage?.source,
            category: 'Search Result',
            timestamp: new Date().toISOString(),
            link: summary.content_urls?.desktop?.page
          };
        } catch (err) {
          return null;
        }
      })
    );

    return c.json({ articles: articles.filter(a => a !== null) });
  } catch (error) {
    console.error('Error searching Wikipedia:', error);
    return c.json({ error: 'Search failed', message: String(error) }, 500);
  }
});

// Route: User registration
app.post('/make-server-e3bffcda/auth/register', async (c) => {
  try {
    const { email, password, name } = await c.req.json();

    // Validate inputs
    if (!email || !password || !name) {
      return c.json({ error: 'Email, password, and name are required' }, 400);
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return c.json({ error: 'Invalid email format' }, 400);
    }

    // Password validation: 8+ chars, 1 uppercase, 1 number
    if (password.length < 8) {
      return c.json({ error: 'Password must be at least 8 characters long' }, 400);
    }
    if (!/[A-Z]/.test(password)) {
      return c.json({ error: 'Password must contain at least one uppercase letter' }, 400);
    }
    if (!/[0-9]/.test(password)) {
      return c.json({ error: 'Password must contain at least one number' }, 400);
    }

    // Create user with Supabase Auth
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      email_confirm: true // Auto-confirm for demo purposes
    });

    if (error) {
      throw error;
    }

    return c.json({ 
      message: 'User registered successfully', 
      user: { id: data.user.id, email: data.user.email, name } 
    });
  } catch (error) {
    console.error('Error in registration:', error);
    return c.json({ error: 'Registration failed', message: String(error) }, 500);
  }
});

// Route: Save/bookmark article
app.post('/make-server-e3bffcda/articles/save', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (authError || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const article = await c.req.json();
    
    // Save to KV store
    const key = `saved_article_${user.id}_${article.id}`;
    await kv.set(key, JSON.stringify({ ...article, userId: user.id, savedAt: Date.now() }));

    return c.json({ message: 'Article saved successfully' });
  } catch (error) {
    console.error('Error saving article:', error);
    return c.json({ error: 'Failed to save article', message: String(error) }, 500);
  }
});

// Route: Get saved articles
app.get('/make-server-e3bffcda/articles/saved', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (authError || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    // Get all saved articles for this user
    const savedArticles = await kv.getByPrefix(`saved_article_${user.id}_`);
    const articles = savedArticles.map(item => JSON.parse(item));

    return c.json({ articles });
  } catch (error) {
    console.error('Error getting saved articles:', error);
    return c.json({ error: 'Failed to get saved articles', message: String(error) }, 500);
  }
});

// Health check
app.get('/make-server-e3bffcda/health', (c) => {
  return c.json({ status: 'ok', timestamp: new Date().toISOString() });
});

Deno.serve(app.fetch);
