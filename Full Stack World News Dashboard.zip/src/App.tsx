import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AlertCircle } from 'lucide-react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { ThemeProvider } from './contexts/ThemeContext';
import { LoginForm } from './components/auth/LoginForm';
import { SignUpForm } from './components/auth/SignUpForm';
import { ForgotPasswordForm } from './components/auth/ForgotPasswordForm';
import { Navbar } from './components/dashboard/Navbar';
import { FilterBar } from './components/dashboard/FilterBar';
import { NewsCard } from './components/dashboard/NewsCard';
import { NewsSkeleton } from './components/dashboard/NewsSkeleton';
import { SearchModal } from './components/dashboard/SearchModal';
import { SavedArticles } from './components/dashboard/SavedArticles';
import { ArticleDetail } from './components/dashboard/ArticleDetail';
import { Alert, AlertDescription } from './components/ui/alert';
import { Toaster } from './components/ui/sonner';
import { toast } from 'sonner@2.0.3';
import type { NewsArticle, NewsFilters } from './types';
import { projectId, publicAnonKey } from './utils/supabase/info';
import { createClient } from './utils/supabase/client';

function AuthScreen() {
  const [mode, setMode] = useState<'login' | 'signup' | 'forgot'>('login');

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 flex items-center justify-center p-4">
      <AnimatePresence mode="wait">
        {mode === 'login' && (
          <LoginForm
            key="login"
            onToggleMode={() => setMode('signup')}
            onForgotPassword={() => setMode('forgot')}
          />
        )}
        {mode === 'signup' && (
          <SignUpForm
            key="signup"
            onToggleMode={() => setMode('login')}
          />
        )}
        {mode === 'forgot' && (
          <ForgotPasswordForm
            key="forgot"
            onBack={() => setMode('login')}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

function Dashboard() {
  const [articles, setArticles] = useState<NewsArticle[]>([]);
  const [filteredArticles, setFilteredArticles] = useState<NewsArticle[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState('');
  const [filters, setFilters] = useState<NewsFilters>({
    category: 'All',
    searchQuery: '',
    dateFilter: 'all'
  });
  const [showSearch, setShowSearch] = useState(false);
  const [showSaved, setShowSaved] = useState(false);
  const [selectedArticle, setSelectedArticle] = useState<NewsArticle | null>(null);

  useEffect(() => {
    fetchNews();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [articles, filters]);

  const fetchNews = async () => {
    try {
      setError('');
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-e3bffcda/news/latest`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`
          }
        }
      );

      if (!response.ok) {
        throw new Error('Failed to fetch news');
      }

      const data = await response.json();
      setArticles(data.articles || []);
    } catch (err: any) {
      console.error('Error fetching news:', err);
      setError(err.message || 'Failed to load news. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await fetchNews();
    setRefreshing(false);
    toast.success('News updated!');
  };

  const applyFilters = () => {
    let filtered = [...articles];

    // Category filter
    if (filters.category !== 'All') {
      filtered = filtered.filter(article => article.category === filters.category);
    }

    // Date filter
    const now = Date.now();
    if (filters.dateFilter !== 'all') {
      filtered = filtered.filter(article => {
        const articleTime = new Date(article.timestamp).getTime();
        const diffInHours = (now - articleTime) / (1000 * 60 * 60);
        
        switch (filters.dateFilter) {
          case 'today':
            return diffInHours < 24;
          case '24h':
            return diffInHours < 24;
          case 'week':
            return diffInHours < 168;
          default:
            return true;
        }
      });
    }

    setFilteredArticles(filtered);
  };

  const handleSaveArticle = async (article: NewsArticle) => {
    try {
      const supabase = createClient();
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session?.access_token) {
        toast.error('Please sign in to save articles');
        return;
      }

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-e3bffcda/articles/save`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(article)
        }
      );

      if (!response.ok) {
        throw new Error('Failed to save article');
      }

      toast.success('Article saved!');
    } catch (error) {
      console.error('Error saving article:', error);
      toast.error('Failed to save article');
    }
  };

  if (selectedArticle) {
    return (
      <ArticleDetail
        article={selectedArticle}
        onBack={() => setSelectedArticle(null)}
        onSave={handleSaveArticle}
      />
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar
        onSearchClick={() => setShowSearch(true)}
        onSavedClick={() => setShowSaved(true)}
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="mb-2">World News Dashboard</h1>
          <p className="text-muted-foreground">
            Live updates from Wikipedia • Automatically refreshed
          </p>
        </motion.div>

        {/* Filter Bar */}
        <div className="mb-8">
          <FilterBar
            filters={filters}
            onFiltersChange={setFilters}
            onRefresh={handleRefresh}
            isRefreshing={refreshing}
          />
        </div>

        {/* Error Alert */}
        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {/* News Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {loading ? (
            <NewsSkeleton />
          ) : filteredArticles.length > 0 ? (
            filteredArticles.map((article, index) => (
              <NewsCard
                key={article.id}
                article={article}
                index={index}
                onReadMore={setSelectedArticle}
                onSave={handleSaveArticle}
              />
            ))
          ) : (
            <div className="col-span-full text-center py-12 bg-card border border-border rounded-xl">
              <h3>No articles found</h3>
              <p className="text-muted-foreground">
                Try adjusting your filters or refresh the page
              </p>
            </div>
          )}
        </div>
      </main>

      {/* Modals */}
      <SearchModal
        isOpen={showSearch}
        onClose={() => setShowSearch(false)}
        onArticleSelect={setSelectedArticle}
      />

      <SavedArticles
        isOpen={showSaved}
        onClose={() => setShowSaved(false)}
        onArticleSelect={setSelectedArticle}
      />
    </div>
  );
}

function AppContent() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center"
        >
          <div className="text-6xl mb-4">🌍</div>
          <h2>Loading...</h2>
        </motion.div>
      </div>
    );
  }

  return user ? <Dashboard /> : <AuthScreen />;
}

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <AppContent />
        <Toaster position="top-right" />
      </AuthProvider>
    </ThemeProvider>
  );
}
