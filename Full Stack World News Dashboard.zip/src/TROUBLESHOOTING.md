# 🔧 Troubleshooting Guide

## Common Deployment Errors & Fixes

### 1. "Build failed: Cannot find package"

**Error Message:**
```
Error: Cannot find module 'react' or 'vite'
```

**Solution:**
```bash
# Make sure package.json exists
ls package.json

# Install dependencies
npm install

# Test build locally
npm run build
```

---

### 2. "Module not found: Can't resolve './utils/supabase/info'"

**Error Message:**
```
Module not found: Error: Can't resolve './utils/supabase/info'
```

**Solution:**
This is already fixed! The app now uses `/utils/supabase/config.ts` instead. Make sure you have the latest code.

---

### 3. "Failed to compile: TypeScript errors"

**Error Message:**
```
Type error: Cannot find name 'React'
```

**Solution:**
```bash
# Reinstall TypeScript
npm install --save-dev typescript @types/react @types/react-dom

# Clean build
rm -rf node_modules package-lock.json
npm install
npm run build
```

---

### 4. "404 Page Not Found on Refresh"

**Error Message:**
App works initially, but shows 404 when you refresh the page.

**Solution:**
Make sure `vercel.json` or `netlify.toml` is in your project root:

**For Vercel** - `vercel.json` should contain:
```json
{
  "rewrites": [
    {
      "source": "/(.*)",
      "destination": "/index.html"
    }
  ]
}
```

**For Netlify** - `netlify.toml` should contain:
```toml
[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200
```

---

### 5. "Authentication not working / Infinite loading"

**Symptoms:**
- Login button does nothing
- Page shows loading forever
- Console shows 401 errors

**Solution:**
1. Check browser console (F12) for errors
2. Verify Supabase backend is running
3. Check network tab for failed requests to `supabase.co`

```javascript
// In browser console, test Supabase connection:
console.log('Testing Supabase...')
```

---

### 6. "News articles not loading / Empty dashboard"

**Symptoms:**
- Dashboard shows "No articles found"
- Refresh button doesn't work
- Console shows fetch errors

**Solution:**
1. **Check Supabase Edge Functions are deployed:**
   - Go to Supabase Dashboard
   - Navigate to Edge Functions
   - Verify `make-server-e3bffcda` is deployed

2. **Test the API endpoint manually:**
   ```bash
   curl https://olyqsjpbgesmyyozudeb.supabase.co/functions/v1/make-server-e3bffcda/health
   ```

3. **Check browser console for CORS errors**

---

### 7. "Import statement outside module"

**Error Message:**
```
Uncaught SyntaxError: Cannot use import statement outside a module
```

**Solution:**
Make sure `package.json` has:
```json
{
  "type": "module"
}
```

---

### 8. "Vite config not found"

**Error Message:**
```
Error: Cannot find vite.config.ts
```

**Solution:**
The `vite.config.ts` file should exist in your root directory. If missing, create it with this content:

```typescript
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './'),
    },
  },
  build: {
    outDir: 'dist',
  },
});
```

---

### 9. "Blank white screen after deployment"

**Symptoms:**
- App deploys successfully
- Shows blank white page
- No errors in build logs

**Solution:**

1. **Check browser console (F12):**
   - Look for JavaScript errors
   - Check for failed imports

2. **Verify base path:**
   In `vite.config.ts`, make sure there's no incorrect base URL:
   ```typescript
   export default defineConfig({
     // Don't add 'base' property unless you need it
     plugins: [react()],
   });
   ```

3. **Check index.html:**
   Make sure `/index.html` exists and has:
   ```html
   <script type="module" src="/src/main.tsx"></script>
   ```

---

### 10. "Environment variables not working"

**Symptoms:**
- App works locally but not in production
- Supabase connection fails on deployed site

**Solution:**

The app already has embedded credentials, so you don't need environment variables. But if you want to use your own:

**For Vercel:**
1. Go to Project Settings → Environment Variables
2. Add: `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`
3. Redeploy

**For Netlify:**
1. Go to Site Settings → Build & deploy → Environment
2. Add the variables
3. Trigger new deploy

---

## 🔍 Debugging Checklist

When something goes wrong, check in this order:

1. ✅ **Local build works?**
   ```bash
   npm run build
   npm run preview
   ```

2. ✅ **All files committed to Git?**
   ```bash
   git status
   ```

3. ✅ **Package.json has all dependencies?**
   ```bash
   cat package.json
   ```

4. ✅ **Config files exist?**
   - `vite.config.ts` ✓
   - `tsconfig.json` ✓
   - `vercel.json` or `netlify.toml` ✓

5. ✅ **Check deployment logs**
   - Vercel: Deployments → View Function Logs
   - Netlify: Deploys → Deploy log

---

## 🆘 Still Stuck?

### Get Detailed Error Information

**In Vercel:**
1. Go to your project
2. Click "Deployments"
3. Click the failed deployment
4. Click "View Function Logs"
5. Copy the full error message

**In Netlify:**
1. Go to "Deploys"
2. Click the failed deploy
3. Read "Deploy log"
4. Look for the first ERROR message

### Test Locally First

```bash
# Clean everything
rm -rf node_modules dist package-lock.json

# Fresh install
npm install

# Build
npm run build

# Preview
npm run preview
```

If it works locally but not in production, the issue is likely:
- Environment variables
- Build configuration
- Platform-specific settings

---

## 📊 Performance Issues

### App is slow to load

**Solutions:**
1. Both Vercel and Netlify use global CDN (already optimized)
2. Check your internet connection
3. Clear browser cache
4. Try incognito/private window

### News refresh takes too long

**Expected behavior:** First load may take 5-10 seconds while fetching from Wikipedia API. Subsequent loads use 5-minute cache and should be instant.

---

## ✅ Success Indicators

Your deployment is successful when:

- ✅ Build completes with "Build Successful" message
- ✅ You can visit the deployed URL
- ✅ App loads without console errors
- ✅ You can sign up / sign in
- ✅ News articles appear
- ✅ Theme toggle works
- ✅ Search functionality works

---

## 💬 Need More Help?

1. Check the full deployment logs
2. Search for the exact error message
3. Verify all configuration files are present
4. Test locally first with `npm run build`
5. Make sure Supabase backend is running

Most issues are solved by:
- Reinstalling dependencies (`npm install`)
- Clearing cache
- Checking config files
- Reading error logs carefully
