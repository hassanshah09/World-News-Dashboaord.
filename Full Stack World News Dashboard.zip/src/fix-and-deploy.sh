#!/bin/bash

echo "🔧 Fixing Deployment Issues..."
echo "================================"
echo ""

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Step 1: Clean old files
echo -e "${YELLOW}Step 1: Cleaning old build artifacts...${NC}"
rm -rf node_modules package-lock.json yarn.lock pnpm-lock.yaml dist
echo -e "${GREEN}✅ Cleaned${NC}"
echo ""

# Step 2: Fresh install
echo -e "${YELLOW}Step 2: Installing dependencies from npm registry...${NC}"
npm install
if [ $? -ne 0 ]; then
    echo -e "${RED}❌ npm install failed${NC}"
    exit 1
fi
echo -e "${GREEN}✅ Dependencies installed${NC}"
echo ""

# Step 3: Verify no JSR packages
echo -e "${YELLOW}Step 3: Verifying dependencies...${NC}"
if grep -q "@jsr" package-lock.json 2>/dev/null; then
    echo -e "${RED}❌ Found @jsr references in lockfile${NC}"
    echo "Cleaning and retrying..."
    rm -rf node_modules package-lock.json
    npm install
else
    echo -e "${GREEN}✅ No JSR packages found${NC}"
fi
echo ""

# Step 4: Test build
echo -e "${YELLOW}Step 4: Testing build...${NC}"
npm run build
if [ $? -ne 0 ]; then
    echo -e "${RED}❌ Build failed${NC}"
    echo ""
    echo "Please check the error messages above."
    exit 1
fi
echo -e "${GREEN}✅ Build successful${NC}"
echo ""

# Step 5: Git status
echo -e "${YELLOW}Step 5: Checking git status...${NC}"
if git rev-parse --git-dir > /dev/null 2>&1; then
    echo "Git repository detected"
    echo ""
    echo "Files to commit:"
    git status --short
    echo ""
    echo -e "${GREEN}Ready to commit and deploy!${NC}"
    echo ""
    echo "Run these commands to deploy:"
    echo -e "${YELLOW}git add .${NC}"
    echo -e "${YELLOW}git commit -m 'Fix: Exclude backend from build'${NC}"
    echo -e "${YELLOW}git push${NC}"
else
    echo "Not a git repository. Initialize with:"
    echo -e "${YELLOW}git init${NC}"
fi
echo ""

echo "================================"
echo -e "${GREEN}🎉 Fix Complete!${NC}"
echo ""
echo "Next steps:"
echo "1. Commit changes: git add . && git commit -m 'Fix build'"
echo "2. Push to GitHub: git push"
echo "3. Deploy to Netlify or Vercel"
echo ""
echo "The app is ready for deployment!"
