#!/bin/bash

# World News Dashboard - Build Test Script
# This script tests if your app is ready for deployment

echo "🌍 World News Dashboard - Build Test"
echo "======================================"
echo ""

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if Node.js is installed
echo "Checking Node.js installation..."
if ! command -v node &> /dev/null; then
    echo -e "${RED}❌ Node.js is not installed${NC}"
    echo "Please install Node.js from https://nodejs.org"
    exit 1
fi
echo -e "${GREEN}✅ Node.js $(node --version) found${NC}"
echo ""

# Check if npm is installed
echo "Checking npm installation..."
if ! command -v npm &> /dev/null; then
    echo -e "${RED}❌ npm is not installed${NC}"
    exit 1
fi
echo -e "${GREEN}✅ npm $(npm --version) found${NC}"
echo ""

# Check required files
echo "Checking required files..."
files=("package.json" "vite.config.ts" "tsconfig.json" "index.html" "App.tsx")
missing_files=()

for file in "${files[@]}"; do
    if [ -f "$file" ]; then
        echo -e "${GREEN}✅ $file${NC}"
    else
        echo -e "${RED}❌ $file not found${NC}"
        missing_files+=("$file")
    fi
done

if [ ${#missing_files[@]} -ne 0 ]; then
    echo ""
    echo -e "${RED}Missing files detected. Please make sure all files are present.${NC}"
    exit 1
fi
echo ""

# Install dependencies
echo "Installing dependencies..."
echo -e "${YELLOW}Running: npm install${NC}"
npm install

if [ $? -ne 0 ]; then
    echo -e "${RED}❌ npm install failed${NC}"
    exit 1
fi
echo -e "${GREEN}✅ Dependencies installed${NC}"
echo ""

# Build the project
echo "Building the project..."
echo -e "${YELLOW}Running: npm run build${NC}"
npm run build

if [ $? -ne 0 ]; then
    echo -e "${RED}❌ Build failed${NC}"
    echo ""
    echo "Common fixes:"
    echo "1. Delete node_modules and package-lock.json, then run npm install"
    echo "2. Check for TypeScript errors in your code"
    echo "3. Make sure all imports are correct"
    exit 1
fi
echo -e "${GREEN}✅ Build successful${NC}"
echo ""

# Check if dist folder was created
if [ -d "dist" ]; then
    echo -e "${GREEN}✅ dist folder created${NC}"
    echo "Build output:"
    du -sh dist
else
    echo -e "${RED}❌ dist folder not found${NC}"
    exit 1
fi
echo ""

# All checks passed
echo "======================================"
echo -e "${GREEN}🎉 All checks passed!${NC}"
echo ""
echo "Your app is ready for deployment!"
echo ""
echo "Next steps:"
echo "1. Push to GitHub: git push"
echo "2. Deploy to Vercel: https://vercel.com"
echo "   OR"
echo "   Deploy to Netlify: https://netlify.com"
echo ""
echo "To preview locally:"
echo "  npm run preview"
echo ""
